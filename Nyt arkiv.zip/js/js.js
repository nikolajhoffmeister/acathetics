/**
 * file: js/js.js
 * purpose: Behaviors
 **/